# Roots Theme

Up to date with Cornerstone v6.1.1

## Install

```
npm install
stencil init
stencil start
```
# lws-bronco-distribution
